"""Engine slot. Any object with `name`, `settings` and `best` fits.

An engine result carries no certificate. Exactness is never delegated to an engine.
"""
from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import chess


@dataclass
class EngineResult:
    move: chess.Move
    score: float | None = None   # from the side to move, if the engine reports one
    depth: int | None = None     # the depth the engine reports, if it reports one


# Optional capabilities. Nothing in this block is needed for an engine to fit the slot: the
# minimum is `name`, `settings` and `best`. An engine may declare the names below in
# `capabilities`, and a goal can ask `supports` before relying on one. The whole block is
# optional and can be removed as a unit if it ever becomes a concern at scale, storage for
# instance. It says nothing about what a goal does with the answers.
LINES = "lines"      # can give several lines for one position
EXCLUDE = "exclude"  # can leave given moves out of the search


class Engine(ABC):
    name: str = "engine"
    settings: dict = {}
    capabilities: frozenset = frozenset()   # optional, see the block above

    @abstractmethod
    def best(self, board: chess.Board, limit=None) -> EngineResult:
        ...

    def supports(self, capability: str) -> bool:   # optional, see the block above
        return capability in self.capabilities

    def candidates(self, board: chess.Board, limit=None, lines: int = 1,
                   exclude=None) -> list[EngineResult]:
        """Optional. Up to `lines` results, best first, with the moves in `exclude` left out.
        Only an engine that declares what it is asked for gives this."""
        raise NotImplementedError(f"{self.name} does not declare the capabilities for candidates")

    def close(self) -> None:
        pass


class RandomEngine(Engine):
    def __init__(self, seed: int = 0):
        self.name = "random"
        self.settings = {"seed": seed}
        self._rng = random.Random(seed)

    def best(self, board, limit=None):
        return EngineResult(self._rng.choice(list(board.legal_moves)))


_VALUES = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 0}


def _material(board: chess.Board, color: chess.Color) -> int:
    total = 0
    for piece_type, value in _VALUES.items():
        total += value * len(board.pieces(piece_type, color))
        total -= value * len(board.pieces(piece_type, not color))
    return total


class OnePlyEngine(Engine):
    """Picks the move with the best material after one ply, ties broken at random."""

    def __init__(self, seed: int = 0):
        self.name = "one_ply"
        self.settings = {"seed": seed}
        self._rng = random.Random(seed)

    def best(self, board, limit=None):
        side = board.turn
        scored = []
        for move in board.legal_moves:
            board.push(move)
            if board.is_checkmate():
                value = 1000
            else:
                value = _material(board, side)
            board.pop()
            scored.append((value, move))
        top = max(v for v, _ in scored)
        choice = self._rng.choice([m for v, m in scored if v == top])
        return EngineResult(choice, score=float(top), depth=1)


class UciEngine(Engine):
    """A local engine that speaks UCI."""

    # Optional. Several lines rely on the engine's MultiPV option, and leaving moves out
    # restricts the root moves of the search.
    capabilities = frozenset({LINES, EXCLUDE})

    def __init__(self, path: str, limit: chess.engine.Limit | None = None, options: dict | None = None):
        import chess.engine
        self.name = path
        self.settings = dict(options or {})
        self._limit = limit or chess.engine.Limit(depth=8)
        self._eng = chess.engine.SimpleEngine.popen_uci(path)
        if options:
            self._eng.configure(options)

    def best(self, board, limit=None):
        info = self._eng.analyse(board, limit or self._limit)
        pv = info.get("pv")
        move = pv[0] if pv else self._eng.play(board, limit or self._limit).move
        score = info.get("score")
        value = None
        if score is not None:
            value = score.pov(board.turn).score(mate_score=100000)
        return EngineResult(move, score=value, depth=info.get("depth"))

    def candidates(self, board, limit=None, lines=1, exclude=None):
        """Optional. See Engine.candidates."""
        legal = list(board.legal_moves)
        if exclude:
            skip = set(exclude)
            legal = [m for m in legal if m not in skip]
        if not legal:
            return []
        infos = self._eng.analyse(board, limit or self._limit, multipv=max(1, lines),
                                  root_moves=legal if exclude else None)
        results = []
        for info in infos:
            pv = info.get("pv")
            if not pv:
                continue
            score = info.get("score")
            value = score.pov(board.turn).score(mate_score=100000) if score is not None else None
            results.append(EngineResult(pv[0], score=value, depth=info.get("depth")))
        return results

    def close(self):
        self._eng.quit()
