"""F: self-play from goals, engines and priors, giving a batch of games.

F supplies the board, the legal moves, the end of a game, and the batch. The goals
supply the rest. A goal is any object with optional hooks:

    move(ctx)  -> a chess.Move, or None to leave the choice to the default
    done(batch) -> True when the batch is complete
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

import chess

from .engine import Engine
from .priors import Priors

DEFAULT_START = chess.STARTING_FEN


@dataclass
class Game:
    start_fen: str
    moves: list[str]
    result: str

    def key(self):
        return (self.start_fen, tuple(self.moves))


@dataclass
class FContext:
    board: chess.Board
    side: chess.Color
    priors_w: Priors
    priors_b: Priors
    engine: Engine
    rng: random.Random
    ply: int

    @property
    def own_priors(self) -> Priors:
        return self.priors_w if self.side == chess.WHITE else self.priors_b


class NullGoal:
    """No goal. The count of games is the goal input."""

    def __init__(self, games: int = 1):
        self.games = games

    def move(self, ctx):
        return None

    def done(self, batch):
        return len(batch) >= self.games


def _default_move(ctx: FContext) -> chess.Move:
    return ctx.engine.best(ctx.board).move


def F(engine_w: Engine, engine_b: Engine, priors_w: Priors | None, priors_b: Priors | None,
      goal_w, goal_b, start: str = DEFAULT_START, seed: int = 0,
      max_plies: int = 200, max_attempts: int | None = None):
    priors_w = priors_w if priors_w is not None else Priors()
    priors_b = priors_b if priors_b is not None else Priors()
    rng = random.Random(seed)
    batch: list[Game] = []
    seen: set = set()
    attempts = 0
    dropped = 0
    cap = max_attempts if max_attempts is not None else 1000

    def done():
        for goal in (goal_w, goal_b):
            check = getattr(goal, "done", None)
            if check is not None and check(batch):
                return True
        return False

    while not done() and attempts < cap:
        attempts += 1
        board = chess.Board(start)
        moves: list[str] = []
        while not board.is_game_over(claim_draw=True) and len(moves) < max_plies:
            side = board.turn
            goal = goal_w if side == chess.WHITE else goal_b
            engine = engine_w if side == chess.WHITE else engine_b
            ctx = FContext(board, side, priors_w, priors_b, engine, rng, len(moves))
            hook = getattr(goal, "move", None)
            move = hook(ctx) if hook is not None else None
            if move is None:
                move = _default_move(ctx)
            if move not in board.legal_moves:
                raise ValueError(f"illegal move {move} from goal or engine at {board.fen()}")
            moves.append(move.uci())
            board.push(move)
        outcome = board.result(claim_draw=True) if board.is_game_over(claim_draw=True) else "*"
        game = Game(start, moves, outcome)
        if game.key() in seen:
            dropped += 1
            continue
        seen.add(game.key())
        batch.append(game)
    return batch, {"attempts": attempts, "duplicates_dropped": dropped, "games": len(batch)}
