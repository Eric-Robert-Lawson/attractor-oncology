"""The loop: F, then P, then F again on the priors that P gave."""
from __future__ import annotations

import importlib.util
from pathlib import Path

from .f import F, DEFAULT_START
from .p import P
from .priors import Priors


def load_goal(path: str, attr: str = "goal"):
    """Fetch stored goal code from a file and return the named object."""
    file = Path(path)
    spec = importlib.util.spec_from_file_location(file.stem, file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return getattr(module, attr)


def loop(cycles, engine_w, engine_b, goal_f_w, goal_f_b, goal_p,
         priors_w=None, priors_b=None, batch=None, start=DEFAULT_START, seed=0, **f_options):
    """With a batch given, the loop starts with P on that batch. Without one, it starts with F."""
    priors_w = priors_w if priors_w is not None else Priors()
    priors_b = priors_b if priors_b is not None else Priors()
    history = []
    given = batch
    for cycle in range(cycles):
        if given is not None:
            batch, f_info = given, {"batch_given": len(given)}
            given = None
        else:
            batch, f_info = F(engine_w, engine_b, priors_w, priors_b, goal_f_w, goal_f_b,
                              start=start, seed=seed + cycle, **f_options)
        priors_w, priors_b = P(priors_w, priors_b, batch, engine_w, engine_b, goal_p)
        history.append({"cycle": cycle, "f": f_info,
                        "priors_w": priors_w.counts(), "priors_b": priors_b.counts()})
    return priors_w, priors_b, history
