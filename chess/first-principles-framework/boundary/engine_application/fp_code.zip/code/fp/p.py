"""P: takes the priors and a batch, and gives new priors.

P supplies the context, which includes the batch merged by position. The goal is the
body: it is called with the context and returns the new priors for each side. What it
returns must be of the specified shape.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator

import chess

from .engine import Engine
from .f import Game
from .priors import Priors, shape_problems
from .structure import BatchStructure, build_structure


@dataclass
class PContext:
    priors_w: Priors
    priors_b: Priors
    batch: list[Game]
    engine_w: Engine
    engine_b: Engine
    structure: BatchStructure

    @staticmethod
    def replay(game: Game) -> Iterator[tuple[chess.Board, chess.Move]]:
        """Yields the board before each move, and the move. The board is reused."""
        board = chess.Board(game.start_fen)
        for text in game.moves:
            move = chess.Move.from_uci(text)
            yield board, move
            board.push(move)


def P(priors_w: Priors | None, priors_b: Priors | None, batch: list[Game],
      engine_w: Engine, engine_b: Engine, goal):
    work_w = priors_w.copy() if priors_w is not None else Priors()
    work_b = priors_b.copy() if priors_b is not None else Priors()
    ctx = PContext(work_w, work_b, batch, engine_w, engine_b, build_structure(batch, work_w.key))
    result = goal(ctx)
    try:
        new_w, new_b = result
    except (TypeError, ValueError):
        raise ValueError("a goal for P must return a pair of priors, one for each side")
    problems = shape_problems(new_w)[:5] + shape_problems(new_b)[:5]
    if problems:
        raise ValueError("priors of the wrong shape: " + "; ".join(problems))
    return new_w, new_b
