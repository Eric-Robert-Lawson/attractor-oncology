"""Priors container.

An entry is held at a position and holds the parts of the d-depth header that its state
of resolution allows: d always, and the index and the symmetry condition only where the
position resolved to a destination. An entry with d alone marks the outer bound of a
proof tree. A position that is not certified is not added.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Callable

import chess


def default_key(board: chess.Board) -> str:
    return board.epd()


def default_segment(board: chess.Board):
    """The segment of a position: its material, with bishops told apart by the colour of
    their squares, its pawn structure and its castling rights.

    The moves that change any of these (captures, pawn moves, loss of castling rights)
    are the irreversible ones, and they lead from one segment to another.
    """
    material = []
    for color in (chess.WHITE, chess.BLACK):
        bishops = board.pieces(chess.BISHOP, color)
        material.append((
            len(board.pieces(chess.PAWN, color)),
            len(board.pieces(chess.KNIGHT, color)),
            len(bishops & chess.BB_LIGHT_SQUARES),
            len(bishops & chess.BB_DARK_SQUARES),
            len(board.pieces(chess.ROOK, color)),
            len(board.pieces(chess.QUEEN, color)),
            len(board.pieces(chess.KING, color)),
        ))
    pawns = (int(board.pieces(chess.PAWN, chess.WHITE)), int(board.pieces(chess.PAWN, chess.BLACK)))
    return (tuple(material), pawns, board.castling_rights)


@dataclass
class Entry:
    d: int | None = None            # the d-depth limit; every entry holds one
    index: int | str | None = None  # into the legend of the boundary: the destination reached
    symmetry: int | str | None = None  # the transformation that gives the destination state


class Priors:
    """Held in segments, one for each irreversible segmented boundary.

    The function that gives the segment of a position is a parameter. Its default is the
    one the documents give: material, pawn structure and castling rights.
    """

    def __init__(self, key: Callable[[chess.Board], str] = default_key,
                 segment: Callable[[chess.Board], object] = default_segment):
        self.key = key
        self.segment = segment
        self._segments: dict = {}

    def get(self, board: chess.Board) -> Entry | None:
        held = self._segments.get(self.segment(board))
        return held.get(self.key(board)) if held else None

    def put(self, board: chess.Board, entry: Entry) -> None:
        self._segments.setdefault(self.segment(board), {})[self.key(board)] = entry

    def __len__(self) -> int:
        return sum(len(held) for held in self._segments.values())

    def __contains__(self, board: chess.Board) -> bool:
        return self.get(board) is not None

    def items(self):
        for held in self._segments.values():
            yield from held.items()

    def segments(self) -> dict:
        return {name: len(held) for name, held in self._segments.items()}

    def copy(self) -> "Priors":
        other = Priors(self.key, self.segment)
        other._segments = deepcopy(self._segments)
        return other

    def counts(self) -> dict:
        values = [e for _, e in self.items()]
        resolved = sum(1 for e in values if e.index is not None)
        return {"entries": len(values), "resolved": resolved,
                "outer_bound": len(values) - resolved, "segments": len(self._segments)}


def shape_problems(priors: "Priors") -> list[str]:
    """What a set of priors must hold to be of the specified shape. Empty when it is."""
    problems = []
    if not isinstance(priors, Priors):
        return ["not a Priors"]
    for key, entry in priors.items():
        if not isinstance(entry, Entry):
            problems.append(f"{key}: not an Entry")
            continue
        if entry.d is None:
            problems.append(f"{key}: an entry with no d is not added")
        elif not isinstance(entry.d, int) or isinstance(entry.d, bool) or entry.d < 0:
            problems.append(f"{key}: d is not a whole number of zero or more")
        if (entry.index is None) != (entry.symmetry is None):
            problems.append(f"{key}: the index and the symmetry condition come together or not at all")
    return problems
