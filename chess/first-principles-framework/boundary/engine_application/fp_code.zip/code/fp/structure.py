"""The structure P builds from a batch: the board states of its lines, merged by position.

Working data for one call of P. It is not stored with the priors.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import chess

from .f import Game
from .priors import default_key


@dataclass
class Node:
    board: chess.Board
    played: dict = field(default_factory=dict)   # move text -> key of the position it led to
    lines: int = 0                               # how many lines of the batch pass through
    game_over: bool = False


@dataclass
class BatchStructure:
    nodes: dict            # key -> Node
    starts: set            # keys where a line begins
    ends: set              # keys where a line ends
    lines: list            # each line as its list of keys, first to last

    def __len__(self):
        return len(self.nodes)


def build_structure(batch: list[Game], key: Callable[[chess.Board], str] = default_key) -> BatchStructure:
    nodes: dict = {}
    starts, ends, lines = set(), set(), []

    def node_for(board: chess.Board) -> str:
        k = key(board)
        node = nodes.get(k)
        if node is None:
            node = nodes[k] = Node(board.copy(), game_over=board.is_game_over())
        return k

    for game in batch:
        board = chess.Board(game.start_fen)
        path = [node_for(board)]
        starts.add(path[0])
        for text in game.moves:
            nodes[path[-1]].lines += 1
            board.push(chess.Move.from_uci(text))
            child = node_for(board)
            nodes[path[-1]].played[text] = child
            path.append(child)
        nodes[path[-1]].lines += 1
        ends.add(path[-1])
        lines.append(path)
    return BatchStructure(nodes, starts, ends, lines)
