"""Ways to bring existing games in as a batch."""
from __future__ import annotations

import io
import os

import chess
import chess.pgn

from .f import DEFAULT_START, Game


def game_from_moves(moves, start: str = DEFAULT_START, result: str = "*") -> Game:
    board = chess.Board(start)
    played = []
    for item in moves:
        move = chess.Move.from_uci(item) if isinstance(item, str) else item
        if move not in board.legal_moves:
            raise ValueError(f"illegal move {move} at {board.fen()}")
        played.append(move.uci())
        board.push(move)
    return Game(start, played, result)


def games_from_pgn(source) -> list[Game]:
    """A path to a PGN file, or PGN text, gives a list of games."""
    if isinstance(source, (str, os.PathLike)) and os.path.exists(source):
        handle = open(source, encoding="utf-8")
    else:
        handle = io.StringIO(str(source))
    games = []
    with handle:
        while True:
            parsed = chess.pgn.read_game(handle)
            if parsed is None:
                break
            moves = [m.uci() for m in parsed.mainline_moves()]
            games.append(Game(parsed.board().fen(), moves, parsed.headers.get("Result", "*")))
    return games
