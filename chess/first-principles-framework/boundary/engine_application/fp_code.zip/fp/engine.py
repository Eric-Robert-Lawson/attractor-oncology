"""Engine slot. Any object with `name`, `settings` and `best` fits.

An engine result carries no certificate. Exactness is never delegated to an engine.
"""
from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import chess


@dataclass
class EngineResult:
    move: chess.Move
    score: float | None = None   # from the side to move, if the engine reports one
    depth: int | None = None     # the depth the engine reports, if it reports one


class Engine(ABC):
    name: str = "engine"
    settings: dict = {}

    @abstractmethod
    def best(self, board: chess.Board, limit=None) -> EngineResult:
        ...

    def close(self) -> None:
        pass


class RandomEngine(Engine):
    def __init__(self, seed: int = 0):
        self.name = "random"
        self.settings = {"seed": seed}
        self._rng = random.Random(seed)

    def best(self, board, limit=None):
        return EngineResult(self._rng.choice(list(board.legal_moves)))


_VALUES = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 0}


def _material(board: chess.Board, color: chess.Color) -> int:
    total = 0
    for piece_type, value in _VALUES.items():
        total += value * len(board.pieces(piece_type, color))
        total -= value * len(board.pieces(piece_type, not color))
    return total


class OnePlyEngine(Engine):
    """Picks the move with the best material after one ply, ties broken at random."""

    def __init__(self, seed: int = 0):
        self.name = "one_ply"
        self.settings = {"seed": seed}
        self._rng = random.Random(seed)

    def best(self, board, limit=None):
        side = board.turn
        scored = []
        for move in board.legal_moves:
            board.push(move)
            if board.is_checkmate():
                value = 1000
            else:
                value = _material(board, side)
            board.pop()
            scored.append((value, move))
        top = max(v for v, _ in scored)
        choice = self._rng.choice([m for v, m in scored if v == top])
        return EngineResult(choice, score=float(top), depth=1)


class UciEngine(Engine):
    """A local engine that speaks UCI."""

    def __init__(self, path: str, limit: chess.engine.Limit | None = None, options: dict | None = None):
        import chess.engine
        self.name = path
        self.settings = dict(options or {})
        self._limit = limit or chess.engine.Limit(depth=8)
        self._eng = chess.engine.SimpleEngine.popen_uci(path)
        if options:
            self._eng.configure(options)

    def best(self, board, limit=None):
        info = self._eng.analyse(board, limit or self._limit)
        pv = info.get("pv")
        move = pv[0] if pv else self._eng.play(board, limit or self._limit).move
        score = info.get("score")
        value = None
        if score is not None:
            value = score.pov(board.turn).score(mate_score=100000)
        return EngineResult(move, score=value, depth=info.get("depth"))

    def close(self):
        self._eng.quit()
