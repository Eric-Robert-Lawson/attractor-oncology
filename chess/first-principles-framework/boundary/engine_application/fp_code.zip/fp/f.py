"""F: self-play from goals, engines and priors, giving a batch.

F supplies the board, the legal moves, the end of a game, and the batch. The goals
supply the rest. A goal is any object with optional hooks:

    batch(run)  -> a list of units, produced in any way the goal chooses, replacing self-play
    start(run)  -> the start of the next game (a FEN or a chess.Board), or None for the default
    move(ctx)   -> a chess.Move, or None to leave the choice to the default
    unit(game)  -> what goes into the batch for a finished game; by default the Game itself
    done(batch) -> True when the batch is complete

F does not fix what a unit of the batch is, or how the batch is made. P takes whatever batch
it is given, so what F gives and what P takes can vary in the same way. The hooks are not
exclusive: a goal may use any of them together, and a goal may call F or its own search from
inside its own hooks.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any

import chess

from .engine import Engine

DEFAULT_START = chess.STARTING_FEN


@dataclass
class Game:
    start_fen: str
    moves: list[str]
    result: str

    def key(self):
        return (self.start_fen, tuple(self.moves))


@dataclass
class FRun:
    """What F gives to the hooks that work on the batch as a whole."""
    priors_w: Any
    priors_b: Any
    engine_w: Engine
    engine_b: Engine
    rng: random.Random
    start: str            # the start F was given
    attempt: int          # how many games have been tried so far


@dataclass
class FContext:
    board: chess.Board
    side: chess.Color
    priors_w: Any
    priors_b: Any
    engine: Engine
    rng: random.Random
    ply: int

    @property
    def own_priors(self) -> Any:
        return self.priors_w if self.side == chess.WHITE else self.priors_b


class NullGoal:
    """No goal. The count of games is the goal input."""

    def __init__(self, games: int = 1):
        self.games = games

    def move(self, ctx):
        return None

    def done(self, batch):
        return len(batch) >= self.games


def _default_move(ctx: FContext) -> chess.Move:
    return ctx.engine.best(ctx.board).move


def F(engine_w: Engine, engine_b: Engine, priors_w: Any, priors_b: Any,
      goal_w, goal_b, start: str = DEFAULT_START, seed: int = 0,
      max_plies: int = 200, max_attempts: int | None = None):
    rng = random.Random(seed)
    batch: list = []
    seen: set = set()
    attempts = 0
    games = 0
    dropped = 0
    cap = max_attempts if max_attempts is not None else 1000

    def done():
        for goal in (goal_w, goal_b):
            check = getattr(goal, "done", None)
            if check is not None and check(batch):
                return True
        return False

    def run_ctx() -> FRun:
        return FRun(priors_w, priors_b, engine_w, engine_b, rng, start, attempts)

    for goal in (goal_w, goal_b):
        produce = getattr(goal, "batch", None)
        if produce is not None:
            made = list(produce(run_ctx()))
            return made, {"attempts": 0, "duplicates_dropped": 0, "games": 0, "units": len(made)}

    def start_of() -> str:
        for goal in (goal_w, goal_b):
            choose = getattr(goal, "start", None)
            if choose is not None:
                chosen = choose(run_ctx())
                if chosen is not None:
                    return chosen.fen() if isinstance(chosen, chess.Board) else chosen
        return start

    def unit_of(game: Game):
        for goal in (goal_w, goal_b):
            make = getattr(goal, "unit", None)
            if make is not None:
                return make(game)
        return game

    while not done() and attempts < cap:
        attempts += 1
        first = start_of()
        board = chess.Board(first)
        moves: list[str] = []
        while not board.is_game_over(claim_draw=True) and len(moves) < max_plies:
            side = board.turn
            goal = goal_w if side == chess.WHITE else goal_b
            engine = engine_w if side == chess.WHITE else engine_b
            ctx = FContext(board, side, priors_w, priors_b, engine, rng, len(moves))
            hook = getattr(goal, "move", None)
            move = hook(ctx) if hook is not None else None
            if move is None:
                move = _default_move(ctx)
            if move not in board.legal_moves:
                raise ValueError(f"illegal move {move} from goal or engine at {board.fen()}")
            moves.append(move.uci())
            board.push(move)
        outcome = board.result(claim_draw=True) if board.is_game_over(claim_draw=True) else "*"
        game = Game(first, moves, outcome)
        if game.key() in seen:
            dropped += 1
            continue
        seen.add(game.key())
        games += 1
        batch.append(unit_of(game))
    return batch, {"attempts": attempts, "duplicates_dropped": dropped, "games": games, "units": len(batch)}
