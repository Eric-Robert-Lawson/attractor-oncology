"""Ways of telling board states and irreversible segmented boundaries apart.

Each is a function that whatever needs it takes as an input, with these as defaults.
Neither belongs to the priors, and F and P demand neither of them of any priors.
"""
import chess


def default_key(board: chess.Board) -> str:
    return board.epd()


def default_segment(board: chess.Board):
    """The segment of a position: its material, with bishops told apart by the colour of
    their squares, its pawn structure and its castling rights.

    The moves that change any of these (captures, pawn moves, loss of castling rights)
    are the irreversible ones, and they lead from one segment to another.
    """
    material = []
    for color in (chess.WHITE, chess.BLACK):
        bishops = board.pieces(chess.BISHOP, color)
        material.append((
            len(board.pieces(chess.PAWN, color)),
            len(board.pieces(chess.KNIGHT, color)),
            len(bishops & chess.BB_LIGHT_SQUARES),
            len(bishops & chess.BB_DARK_SQUARES),
            len(board.pieces(chess.ROOK, color)),
            len(board.pieces(chess.QUEEN, color)),
            len(board.pieces(chess.KING, color)),
        ))
    pawns = (int(board.pieces(chess.PAWN, chess.WHITE)), int(board.pieces(chess.PAWN, chess.BLACK)))
    return (tuple(material), pawns, board.castling_rights)
