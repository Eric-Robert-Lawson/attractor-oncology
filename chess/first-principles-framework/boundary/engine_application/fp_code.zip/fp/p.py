"""P: takes the priors and a batch, and gives new priors.

P fixes no data format for the priors. It hands the goal the priors it was given, without
copying or reading them, and None is zero priors. A requirement on the priors belongs to the
goal that chooses it.

P does not fix what a unit of the batch is. The batch reaches the goal as it was given.
The context also holds the batch merged by position when the structure builder can read
its units (the default reads games, boards and board state text). Another builder can be
passed, or None for no structure. The goal is the body: it is called with the context and
returns the new priors for each side, as a pair.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterator

import chess

from .engine import Engine
from .f import Game
from .structure import BatchStructure, build_structure


@dataclass
class PContext:
    priors_w: Any
    priors_b: Any
    batch: list
    engine_w: Engine
    engine_b: Engine
    structure: BatchStructure | None

    @staticmethod
    def replay(game: Game) -> Iterator[tuple[chess.Board, chess.Move]]:
        """Yields the board before each move, and the move. The board is reused."""
        board = chess.Board(game.start_fen)
        for text in game.moves:
            move = chess.Move.from_uci(text)
            yield board, move
            board.push(move)


def P(priors_w: Any, priors_b: Any, batch: list,
      engine_w: Engine, engine_b: Engine, goal, structure=build_structure):
    built = structure(batch) if structure is not None else None
    ctx = PContext(priors_w, priors_b, batch, engine_w, engine_b, built)
    result = goal(ctx)
    try:
        new_w, new_b = result
    except (TypeError, ValueError):
        raise ValueError("a goal for P must return a pair of priors, one for each side")
    return new_w, new_b
