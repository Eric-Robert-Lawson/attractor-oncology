"""The structure P can build from a batch: the board states of its units, merged by position.

A unit of the batch is a Game (a line of board states), a chess.Board, or the text of a
board state (FEN). A board state is a line of one board state. Another kind of unit is
not handled here: P is given another builder, or none, and the batch reaches the goal as
it was given.

Working data for one call of P. It is not stored with the priors. How board states are told
apart is the builder's own input.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import chess

from .f import Game
from .identify import default_key


@dataclass
class Node:
    board: chess.Board
    played: dict = field(default_factory=dict)   # move text -> key of the position it led to
    lines: int = 0                               # how many lines of the batch pass through
    game_over: bool = False


@dataclass
class BatchStructure:
    nodes: dict            # key -> Node
    starts: set            # keys where a line begins
    ends: set              # keys where a line ends
    lines: list            # each line as its list of keys, first to last

    def __len__(self):
        return len(self.nodes)


def _line_of(unit):
    """Gives the starting board and the moves of a unit."""
    if isinstance(unit, Game):
        return chess.Board(unit.start_fen), unit.moves
    if isinstance(unit, chess.Board):
        return unit.copy(), []
    if isinstance(unit, str):
        return chess.Board(unit), []
    raise TypeError(f"no structure for a unit of type {type(unit).__name__}")


def build_structure(batch: list, key: Callable[[chess.Board], str] = default_key) -> BatchStructure:
    nodes: dict = {}
    starts, ends, lines = set(), set(), []

    def node_for(board: chess.Board) -> str:
        k = key(board)
        node = nodes.get(k)
        if node is None:
            node = nodes[k] = Node(board.copy(), game_over=board.is_game_over())
        return k

    for unit in batch:
        board, moves = _line_of(unit)
        path = [node_for(board)]
        starts.add(path[0])
        for text in moves:
            nodes[path[-1]].lines += 1
            board.push(chess.Move.from_uci(text))
            child = node_for(board)
            nodes[path[-1]].played[text] = child
            path.append(child)
        nodes[path[-1]].lines += 1
        ends.add(path[-1])
        lines.append(path)
    return BatchStructure(nodes, starts, ends, lines)
