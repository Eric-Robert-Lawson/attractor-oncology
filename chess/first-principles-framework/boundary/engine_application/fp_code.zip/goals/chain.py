"""Chains stored segments of goal code.

Each segment is called with the context and the output of the segment before it (None for
the first). The chain gives the output of the last segment. It reads nothing in any output
and depends on no segment. P calls the chain as its goal, and F calls it through the batch
hook. The end of a chain must give what its function gives.
"""


def chain(*segments):
    def run(context):
        output = None
        for segment in segments:
            output = segment(context, output)
        return output

    run.batch = run
    return run
