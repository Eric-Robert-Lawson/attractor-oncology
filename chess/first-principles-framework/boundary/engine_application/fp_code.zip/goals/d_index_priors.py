"""One stored choice of what a prior holds and of its data format: d and an index.

This is an integrated specification and not part of F or P, which fix no format. Other
formats are other files, and none of them is required. A goal that chooses this one uses
the container, and ends its chain with `check`, which refuses anything else.

An entry is held at a position and holds the parts of the d-depth header that its state
of resolution allows: d always, and the index only where the position resolved to a
destination. An entry with d alone marks the outer bound of a proof tree. A position that
is not certified is not added. No symmetry condition is held with an entry.

No priors at all is None, which is zero priors. P hands a goal the priors it was given, so
a goal that changes them takes a copy first.

Import it as goals.d_index_priors, so that every user of it shares one container class.
"""
from copy import deepcopy
from dataclasses import dataclass
from typing import Callable

import chess

from fp.identify import default_key, default_segment


@dataclass
class Entry:
    d: int | None = None            # the d-depth limit; every entry holds one
    index: int | str | None = None  # into the legend of the boundary: the destination reached


class Priors:
    """Held in segments, one for each irreversible segmented boundary."""

    def __init__(self, key: Callable[[chess.Board], str] = default_key,
                 segment: Callable[[chess.Board], object] = default_segment):
        self.key = key
        self.segment = segment
        self._segments: dict = {}

    def get(self, board: chess.Board) -> Entry | None:
        held = self._segments.get(self.segment(board))
        return held.get(self.key(board)) if held else None

    def put(self, board: chess.Board, entry: Entry) -> None:
        self._segments.setdefault(self.segment(board), {})[self.key(board)] = entry

    def __len__(self) -> int:
        return sum(len(held) for held in self._segments.values())

    def __contains__(self, board: chess.Board) -> bool:
        return self.get(board) is not None

    def items(self):
        for held in self._segments.values():
            yield from held.items()

    def segments(self) -> dict:
        return {name: len(held) for name, held in self._segments.items()}

    def copy(self) -> "Priors":
        other = Priors(self.key, self.segment)
        other._segments = deepcopy(self._segments)
        return other

    def counts(self) -> dict:
        values = [e for _, e in self.items()]
        resolved = sum(1 for e in values if e.index is not None)
        return {"entries": len(values), "resolved": resolved,
                "outer_bound": len(values) - resolved, "segments": len(self._segments)}


def shape_problems(priors) -> list[str]:
    """What a set of priors must hold to be of this format. Empty when it is."""
    if priors is None:
        return []
    if not isinstance(priors, Priors):
        return ["not a Priors"]
    problems = []
    for key, entry in priors.items():
        if not isinstance(entry, Entry):
            problems.append(f"{key}: not an Entry")
            continue
        if entry.d is None:
            problems.append(f"{key}: an entry with no d is not added")
        elif not isinstance(entry.d, int) or isinstance(entry.d, bool) or entry.d < 0:
            problems.append(f"{key}: d is not a whole number of zero or more")
    return problems


def check(ctx, previous):
    """Segment for the end of a chain: passes on a pair of priors of this format."""
    new_w, new_b = previous
    problems = shape_problems(new_w)[:5] + shape_problems(new_b)[:5]
    if problems:
        raise ValueError("priors of the wrong shape: " + "; ".join(problems))
    return new_w, new_b
