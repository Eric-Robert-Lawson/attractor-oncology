"""Stored goal for P: adds nothing. What no check has resolved is not added to the priors.
Also serves as the last segment of a chain."""


def goal(ctx, previous=None):
    return ctx.priors_w, ctx.priors_b
