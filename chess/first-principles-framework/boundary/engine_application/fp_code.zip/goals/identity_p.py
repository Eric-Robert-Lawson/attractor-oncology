"""Stored goal for P: adds nothing. What no check has resolved is not added to the priors."""


def goal(ctx):
    return ctx.priors_w, ctx.priors_b
