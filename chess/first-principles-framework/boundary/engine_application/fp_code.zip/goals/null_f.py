"""Stored goal for F: no goal, a fixed number of games."""
from fp import NullGoal

goal = NullGoal(games=5)
