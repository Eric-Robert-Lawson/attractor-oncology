"""Segment of goal code: enumerates the proof tree from the board states of the batch, pruned.

Stops at the proof tree. Its output is the tree, carried to the next segment of a chain.
Nothing is certified, no d or index is written, and it gives no priors, so it is not a goal
for P by itself.

The pruned tree drops a ply when the board state it leads to is proven, inside the tree, to be
a win for the side to move there. Draws, wins and anything not proven are kept, and nothing is
stored to mark what was dropped. Values are proven by backward induction after each layer, and
a state with moves but no kept plies is lost. prune=False keeps the whole tree, to compare with.

Parameters that no statement settles, each with a stand-in default:
  depth_for(i, boards)  plies from board state i. Stand-in: flat. It sees the whole batch.
  expand(board)         the plies from a board state. Stand-in: every legal ply.
  limit                 the proof size limit in bytes, or None. Size is counted as the length of the
                        text key of each state held plus the text of each ply held. Stand-in.
  order                 ply by ply from the anchors, states merged by their key, each
                        state given the most depth any route gives it. Stand-in.
  key(board)            what tells board states apart. Stand-in: the text of the board state.
  segment(board)        what tells irreversible segmented boundaries apart. Stand-in: material,
                        pawn structure and castling rights.
  remember              keep the key of every state proven lost for the side that would play into it,
                        so that a ply to it is not held again. This is explicit storage and it is counted
                        in the peak. Stand-in: off.
  ends                  a state where the game has ended, a ply that changes the segment, and the
                        depth allowed. Values at a segment change and at the depth are not proven.
"""
from collections import deque

from fp.identify import default_key, default_segment


def all_legal(board):
    return sorted(board.legal_moves, key=lambda m: m.uci())


class Node:
    __slots__ = ("kind", "children")

    def __init__(self, kind):
        self.kind = kind            # expanded, frontier, downstream, lost, drawn (the last two: game ended)
        self.children = {}          # ply text -> key


class ProofTree:
    def __init__(self):
        self.nodes = {}             # key -> Node
        self.anchors = []           # keys, in the order of the batch
        self.size = 0               # bytes held, by the stand-in count
        self.peak = 0               # the most bytes held at any moment, with the remembered keys
        self.lost = set()           # keys remembered as proven lost (only when remember is on)
        self.stopped = False        # True when the limit ended the expansion


def proven(nodes):
    """W, L or D for the side to move, for the states where the tree proves it."""
    val, parents, need, wins, draws, todo = {}, {}, {}, {}, {}, deque()
    for k, n in nodes.items():
        if n.kind == "lost" or (n.kind == "expanded" and not n.children):
            val[k] = "L"; todo.append(k)
        elif n.kind == "drawn":
            val[k] = "D"; todo.append(k)
        elif n.kind == "expanded":
            need[k], wins[k], draws[k] = len(n.children), 0, 0
            for c in n.children.values():
                parents.setdefault(c, []).append(k)
    while todo:
        k = todo.popleft(); v = val[k]
        for p in parents.get(k, ()):
            if p in val:
                continue
            if v == "L":
                val[p] = "W"; todo.append(p); continue
            if v == "W":
                wins[p] += 1
            else:
                draws[p] += 1
            if wins[p] + draws[p] == need[p]:
                val[p] = "L" if draws[p] == 0 else "D"; todo.append(p)
    return val


def _prune(tree, expanded_to):
    """Drop plies to states proven lost for the side that plays them, and what only exists below them."""
    val = proven(tree.nodes)
    anchors = set(tree.anchors)
    gone = {k for k, v in val.items() if v == "W" and k not in anchors}
    if not gone:
        return gone
    for n in tree.nodes.values():
        if n.kind == "expanded":
            n.children = {p: c for p, c in n.children.items() if c not in gone}
    reach, stack = set(), list(anchors)
    while stack:
        k = stack.pop()
        if k in reach or k in gone:
            continue
        reach.add(k); stack.extend(tree.nodes[k].children.values())
    for k in [k for k in tree.nodes if k not in reach]:
        del tree.nodes[k]; expanded_to.pop(k, None)
    tree.size = sum(len(k) for k in tree.nodes) + sum(len(p) for n in tree.nodes.values() for p in n.children)
    return gone


def build(boards, depth_for, key, segment, expand=all_legal, limit=None, prune=True, remember=False):
    tree = ProofTree()
    layer, expanded_to = {}, {}                # layer: key -> (board, plies still allowed)
    for i, board in enumerate(boards):
        k = key(board); depth = depth_for(i, boards)
        tree.anchors.append(k)
        if k not in layer or layer[k][1] < depth:
            layer[k] = (board.copy(stack=False), depth)

    def node_for(k, kind):
        n = tree.nodes.get(k)
        if n is None:
            n = tree.nodes[k] = Node(kind); tree.size += len(k)
        return n

    while layer and not tree.stopped:
        nxt = {}
        for k, (board, remaining) in layer.items():
            node = node_for(k, "frontier")
            if board.is_game_over():
                node.kind = "lost" if board.is_checkmate() else "drawn"
                continue
            if expanded_to.get(k, -1) >= remaining:
                continue
            if remaining == 0:
                continue
            here = segment(board)
            for move in expand(board):
                text = move.uci(); board.push(move); ck = key(board)
                if ck in tree.lost:
                    board.pop(); continue
                changed = segment(board) != here
                node_for(ck, "downstream" if changed else "frontier")
                if text not in node.children:
                    node.children[text] = ck; tree.size += len(text)
                if not changed and (ck not in nxt or nxt[ck][1] < remaining - 1):
                    nxt[ck] = (board.copy(stack=False), remaining - 1)
                board.pop()
            node.kind = "expanded"; expanded_to[k] = remaining
            held = tree.size + sum(len(k) + 1 for k in tree.lost) if tree.lost else tree.size
            tree.peak = max(tree.peak, held)
            if limit is not None and held >= limit:
                tree.stopped = True
                break
        if prune:
            gone = _prune(tree, expanded_to)
            if remember:
                tree.lost |= gone
        layer = {k: v for k, v in nxt.items() if k in tree.nodes}
    return tree


class ProofTreeGoal:
    def __init__(self, depth_for, expand=all_legal, limit=None, prune=True, remember=False,
                 key=default_key, segment=default_segment):
        self.depth_for, self.expand, self.limit, self.prune, self.remember = depth_for, expand, limit, prune, remember
        self.key, self.segment = key, segment

    def __call__(self, ctx, previous=None):
        s = ctx.structure
        if s is None:
            raise ValueError("this goal reads the structure that P builds from the board states of the batch")
        boards = [s.nodes[line[0]].board for line in s.lines]       # one anchor for each unit, in order
        return build(boards, self.depth_for, self.key, self.segment,
                     self.expand, self.limit, self.prune, self.remember)


def flat(depth):
    return lambda i, boards: depth


segment = ProofTreeGoal(flat(4))
