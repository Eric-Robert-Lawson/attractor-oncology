import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from fp import OnePlyEngine, RandomEngine, P, load_goal

here = Path(__file__).parent
path = here / "goals" / "proof_tree_p.py"
ProofTreeGoal, flat = load_goal(path, "ProofTreeGoal"), load_goal(path, "flat")
chain = load_goal(here / "goals" / "chain.py", "chain")
unchanged = load_goal(here / "goals" / "identity_p.py")

# a batch of board states
batch = ["8/8/8/6Q1/1K6/8/8/k7 w - - 0 1", "3Q4/8/8/8/8/7k/8/4K3 w - - 0 1"]
depth = 5

for label, options in [("whole tree", dict(prune=False)), ("pruned", dict()), ("pruned, with a record of lost states", dict(remember=True))]:
    seen = []

    def look(ctx, tree):          # a segment that reads the tree and carries it on
        seen.append(tree)
        return tree

    goal = chain(ProofTreeGoal(flat(depth), **options), look, unchanged)
    start = time.perf_counter()
    P(None, None, batch, OnePlyEngine(seed=1), RandomEngine(seed=2), goal)
    tree = seen[0]
    print(f"{label:<38} states {len(tree.nodes):>6}  bytes {tree.size:>8}  peak {tree.peak:>8}  seconds {time.perf_counter() - start:.2f}")
