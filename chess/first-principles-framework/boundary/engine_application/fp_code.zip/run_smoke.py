import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from fp import OnePlyEngine, RandomEngine, loop, load_goal

here = Path(__file__).parent
goal_f = load_goal(here / "goals" / "null_f.py")
goal_p = load_goal(here / "goals" / "identity_p.py")

# a small start, so games end quickly
START = "8/8/8/4k3/8/8/4K3/R7 w - - 0 1"

pw, pb, hist = loop(
    3, OnePlyEngine(seed=1), RandomEngine(seed=2), goal_f, goal_f, goal_p,
    start=START, seed=10, max_plies=60,
)
for h in hist:
    print(h)
print("final white priors", pw)
print("final black priors", pb)
